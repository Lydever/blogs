<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="0.1;url=./login.php">
<title>退出登录</title>
</head>
<body>
<center><a>你已经安全退出，如果需要重新登陆，请点击</a><a href="login.php"><strong>重新登陆</strong></a></center>
</body>
</html>