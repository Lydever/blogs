<?php
/* Smarty version 3.1.30, created on 2016-12-08 23:24:20
  from "H:\phpStudy\WWW\Worker\Blog\templates\footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58497b2449d338_39920921',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '10642cdbc7caf87993cb92af2820d28ac9175d3e' => 
    array (
      0 => 'H:\\phpStudy\\WWW\\Worker\\Blog\\templates\\footer.tpl',
      1 => 1481210512,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58497b2449d338_39920921 (Smarty_Internal_Template $_smarty_tpl) {
?>
</div>

<div id = "footer">
    <div class = "main box">
        <p class = "f-right t-right"> 联系我们 | 招聘信息 使用须知</p>
        <p class = "f-left">Copyright &copy;&nbsp;2016 <a href="http://drops.blbana.cc/">BlBana</a></p>
    </div>
</div>
</body>
</html><?php }
}
