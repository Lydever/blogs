<?php
/* Smarty version 3.1.30, created on 2016-12-08 20:50:24
  from "H:\phpStudy\WWW\Worker\Blog\templates\index.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58495710a3a8b2_77600289',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3c7acfabe4a48f205d8ee223a92d9be307622f43' => 
    array (
      0 => 'H:\\phpStudy\\WWW\\Worker\\Blog\\templates\\index.html',
      1 => 1481201068,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58495710a3a8b2_77600289 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta http-equiv="content-language" content="en" />
	<meta name="description" content="[HERE PASTE YOUR DESCRIPTION]" />
	<meta name="author" content="Template:TemplatesDock " />
	<link rel="stylesheet" media="screen,projection" type="text/css" href="css/main.css" />
	<link rel="stylesheet" media="screen,projection" type="text/css" href="css/skin.css" />
	<?php echo '<script'; ?>
 type="text/javascript" src="javascript/cufon-yui.js"><?php echo '</script'; ?>
>
	
	<?php echo '<script'; ?>
 type="text/javascript">Cufon.replace('h1, h2, h3, h4, h5, h6', {hover:true);<?php echo '</script'; ?>
>
	<title>PHP BlogSystem</title>
</head>

<body>

<div class="main">

	<!-- HEADER -->
	<div id="header" class="box">

		<h1 id="logo">PHP<span> BlogSystem</span></h1>

		<!-- NAVIGATION -->
		<ul id="nav">
			<li class="current"><a href="#">首页</a></li>
			<li><a href="#">我的博客</a></li>
			<li><a href="#">登录/注册</a></li>
		</ul>
		
	</div> <!-- /header -->
	<!-- COLUMNS -->
	<div id="section" class="box">

		<!-- CONTENT -->
		<div id="content">

			<!-- LIST OF ARTICLES -->
			<ul class="articles box">
				<li>
					<h2><a href="#">博客的title</a></h2>

					<div class="article-info box">

						<p class="f-right"><a href="#" class="comment">评论 (15)</a></p>

						<p class="f-left">2014-3-19 15:50:50 | 作者 <a href="#">Dnnn帅哥</a> </p>

					</div> <!-- /article-info -->	

					<p>This is a free web template by  This work is distributed under theCreative Commons Attribution 3.0 License, which means that you are free to adapt, copy, distribute and transmit the work. You must attribute the work in the manner specified by the author or licensor (don´t remove our backlink from footer...
					</p>
					<p class="more"><a href="#">查看全文&raquo;</a></p>
				</li>
				<li>
					<h2><a href="#">博客的title</a></h2>

					<div class="article-info box">

						<p class="f-right"><a href="#" class="comment">评论 (15)</a></p>

						<p class="f-left">2014-3-19 15:50:50 | 作者 <a href="#">Dnnn帅哥</a> </p>

					</div> <!-- /article-info -->	

					<p>This is a free web template by  This work is distributed under theCreative Commons Attribution 3.0 License, which means that you are free to adapt, copy, distribute and transmit the work. You must attribute the work in the manner specified by the author or licensor (don´t remove our backlink from footer...
					</p>
					<p class="more"><a href="#">查看全文&raquo;</a></p>
				</li>
				<li>
					<h2><a href="#">博客的title</a></h2>

					<div class="article-info box">

						<p class="f-right"><a href="#" class="comment">评论 (15)</a></p>

						<p class="f-left">2014-3-19 15:50:50 | 作者 <a href="#">Dnnn帅哥</a> </p>

					</div> <!-- /article-info -->	

					<p>This is a free web template by  This work is distributed under theCreative Commons Attribution 3.0 License, which means that you are free to adapt, copy, distribute and transmit the work. You must attribute the work in the manner specified by the author or licensor (don´t remove our backlink from footer...
					</p>
					<p class="more"><a href="#">查看全文&raquo;</a></p>
				</li>
				
			</ul>

			<!-- PAGINATION -->
			<div class="pagination box">

				<p class="f-right">
					<a href="#" class="current">1</a>
					<a href="#">2</a>
					<a href="#">3</a>
					<a href="#">4</a>
					<a href="#">5</a>
					<a href="#">6</a>
					<a href="#">7</a>
					<a href="#">下一页 &raquo;</a>
				</p>
				
				<p class="f-left"> 1 / 13 页</p>

			</div> 
		
		</div> 

		<!-- SIDEBAR -->
		<div id="aside">

			<!-- SIDEBAR MENU -->
			<h3>分类</h3>
			
			<ul class="menu">
				<li class="current"><a href="#">全部</a></li>
				<li><a href="#">个人心情</a></li>
				<li><a href="#">历史迷雾</a></li>
				<li><a href="#">文艺清新</a></li>
				<li><a href="#">技术控</a></li>
				<li><a href="#">幽默搞笑</a></li>
			</ul>		
		
			<h3 class="nomb">名人推荐</h3>
			
			<ul class="sponsors">
				<li>
					<a href="#">Black</a><br />
					我的风景啊吧付款即可不急哈是丢噶空间吧可是记得把电脑
				</li>
				<li>
					<a href="#">TemplatesDock</a><br />
					我的风景啊吧付款即可不急哈是丢噶空间吧可是记得把电脑撒大大大
					
				</li>
				<li>
					<a href="#">AppsTemplates</a><br />
					我的风景啊吧付款即可不急哈是丢噶空间吧可是记得把电脑撒大大大
				</li>
				<li>
					<a href="#">AdminSquare</a><br />
					我的风景啊吧付款即可不急哈是丢噶空间吧可是记得把电脑撒大大大
				</li>	
			</ul>			
		
		</div> <!-- /aside -->

	</div> <!-- /section -->

</div> <!-- /main -->	
	
<!-- FOOTER -->
<div id="footer">

	<div class="main box">
		<p class="f-right t-right"> 联系我们 | 招聘信息 | 网站律师  使用须知</p>
		<p class="f-left">Copyright &copy;&nbsp;2015 <a href="http://www.maiziedu.com/">麦子学院</a></p>
	</div> 

</div> <!-- /footer -->
</body>
</html>
<?php }
}
