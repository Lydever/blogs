<?php
/* Smarty version 3.1.30, created on 2016-12-11 21:47:58
  from "H:\phpStudy\WWW\Worker\Blog\templates\succ.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_584d590eae02f0_24150768',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '59a9021d40bf40e8092d0a6486d15d2fe5391349' => 
    array (
      0 => 'H:\\phpStudy\\WWW\\Worker\\Blog\\templates\\succ.tpl',
      1 => 1481464003,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_584d590eae02f0_24150768 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<meta http-equiv="Refresh" content="3; url=http://localhost/Worker/Blog/"/>

	<div>
		<div style="text-align:center">
			<h1>注册成功</h1>
			<p><a href="http://localhost/Worker/Blog/">3秒后跳转,点击跳转...</a></p>
		</div>
	</div>


</div> 	
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
