<?php
/**
 * Created by PhpStorm.
 * User: BBana
 * Date: 2016/12/9
 * Time: 0:59
 */
require_once "ModelBase.class.php";

class LoginModel extends ModelBase {
    //逻辑执行
    public function checkparams() {

    }

    //参数检检查
    public function preform() {

    }
}