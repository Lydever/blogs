<?php
require_once 'include/init.php';
// phpinfo();