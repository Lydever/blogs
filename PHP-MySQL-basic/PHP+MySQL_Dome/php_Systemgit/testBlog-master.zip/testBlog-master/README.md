# README

这是一个个人的练习项目，目的是为了熟悉网页开发基本技能。

项目实现了博客的最基本的功能，包括文章管理，用户管理。

+ 前端采用BootStrap框架，并使用了[CleanBlog](http://startbootstrap.com/template-overviews/clean-blog/)模板。

+ 后端使用PHP编写，MVC架构，未使用框架。