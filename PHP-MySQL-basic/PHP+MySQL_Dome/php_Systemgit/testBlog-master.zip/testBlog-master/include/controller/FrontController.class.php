<?php
// 前台控制器
abstract class FrontController extends Controller
{

}